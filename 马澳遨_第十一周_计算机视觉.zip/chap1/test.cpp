﻿#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>   

int main()
{
	cv::Mat image;
		std::cout << "This image is " << image.rows << "x"<< image.cols << std::end;
	image = cv::imread("puppy.bmp");

	//定义窗口
	cv::namedWindow("Original Image");  //区分不同的窗口
	//显示图像
	cv::imshow("Original Image", image);

	cv::Mat result;
	cv::flip(image, result, 1);
	cv::namedWindow("Output Image");
	cv::imshow("Output Image", result);


	if (image.empty()) {
		std::cout << "Error reading image..." << std::endl;
		return 0;
	}



}





