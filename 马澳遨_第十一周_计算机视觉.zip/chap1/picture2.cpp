﻿

#include <iostream>
#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>   

int main()
{
	//显示和翻转图片
	cv::Mat image;
	std::cout << "This empty image is "<< image.rows << "x" << image.cols << std::endl;	
	image = cv::imread("cat.jpg", cv::IMREAD_COLOR);
	//cv::namedWindow("Original Image");
	//cv::imshow("Original Image", image);
	cv::Mat result;
	cv::flip(image, result, 1);
	//cv::namedWindow("Output Image");
	//cv::imshow("Output Image", result);


	cv::namedWindow("Drawing on an image");
	cv::circle(
		image,
		cv::Point(0, 0),
		65,
		0,
		3
	);

	cv::putText(
		image,
		"This is a dog.",
		cv::Point(40, 200),
		cv::FONT_HERSHEY_PLAIN,
		2.0,
		255,
		2);

	//cv::imshow("Drawing on an image", image);
	//cv::waitKey(0);

	//图像的创建
	cv::Mat image1(240, 320, CV_8U, 100);
	cv::namedWindow("image1");
	//cv::imshow("image1", image1);
	//cv::waitKey(0);

	//浅拷贝和深拷贝
	cv::Mat image3 = cv::imread("cat.jpg");
	cv::Mat image4(image3);
	
	image1 = image3;
	image3.copyTo(image2);
	cv::Mat image5 = image3.clone();
	cv::flip(image3, image3, 1);

	//把一个logo插入到大图像上
	cv::Mat logo = cv::imread("smalllogo.png");
	cv::Mat imageROI(image,
		cv::Rect(image.cols - logo.cols, image.rows - logo.rows,
			logo.cols, logo.rows));

	cv::Mat mask(logo);

	logo.copyTo(imageROI,mask);

	cv::namedWindow("image");
	cv::imshow("image", image);


	)









}


