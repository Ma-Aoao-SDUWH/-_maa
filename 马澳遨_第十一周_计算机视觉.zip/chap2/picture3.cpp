﻿

#include <iostream>
#include<random>
#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>


//椒盐函数
void salt(cv::Mat image, int n)
{
	std::default_random_engine generator;
	std::uniform_int_distribution<int>
		randomRow(0, image.rows - 1);
	std::uniform_int_distribution<int>
		randomCol(0, image.cols - 1);

	int i, j;
	for (int k = 0; k < n; k++) {
		i = randomCol(generator);
		j = randomRow(generator);
		if (image.type() == CV_8UC1)
		{
			image.at<uchar>(i, j) = 255;
		}
		else if (image.type()==CV_8UC3)
		{
			image.at<cv::Vec3b>(j, i)[0] = 255;
			image.at<cv::Vec3b>(j, i)[1] = 255;
			image.at<cv::Vec3b>(j, i)[2] = 255;
		}

	}

}


//指针扫描函数
void colorReduce(cv::Mat image, int div = 64)
{
	int n1 = image.rows;
	int nc = image.cols * image.channels();
	for (int j = 0; j < n1; j++) {
		uchar* data = image.ptr<uchar>(j);
		for (int i=0; i < nc; i++) {
			data[i] = data[i] / div * div + div / 2;
		}
	}
}


//扫描图像并访问相邻像素(锐化)
void sharpen(const cv::Mat &image,cv::Mat &result)
{
	result.create(image.size(), image.type());
	int nchannels = image.channels();
	for (int j = 1; j < image.rows - 1; j++) {
		const uchar* previous = image.ptr<const uchar>(j - 1);
		const uchar* current = image.ptr<const uchar>(j);
		const uchar* next = image.ptr<const uchar>(j + 1);

		uchar* output = result.ptr<uchar>(j);
		for (int i = nchannels; i < (image.cols - 1) * nchannels; i++)
		{
			*output++ = cv::saturate_cast<uchar>(
				5 * current[i] - current[i - nchannels] -
				current[i + nchannels] - previous[i] - next[i]);
		}
	}

	result.row(0).setTo(cv::Scalar(0));
	result.row(result.rows - 1).setTo(cv::Scalar(0));
	result.col(0).setTo(cv::Scalar(0));
	result.col(result.cols - 1).setTo(cv::Scalar(0));
}




int main()
{
	cv::Mat image = cv::imread("boldt.jpg");
	cv::Mat result;
	cv::Mat image2(cv::Size(320, 240), CV_8UC3, cv::Scalar(0, 0, 255));

	cv::addWeighted(image, 0.7, image2, 0.9, 0., result);

	cv::namedWindow("result");
	cv::imshow("result", result);
	cv::waitKey(0);

}

