#define COLORDETECT

#include<iostream>
#include<opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include<opencv2/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include<vector>
#include<opencv2/highgui.hpp>
#include"colordetector.hpp"

int main






