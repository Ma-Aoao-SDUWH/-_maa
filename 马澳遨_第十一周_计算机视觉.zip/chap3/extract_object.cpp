﻿#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>

int main()
{
	//读入输入图像
	cv::Mat image = cv::imread("boldt.jpg");
	if (!image.data)
		return 0;
	//
	//显示输入图像
	cv::namedWindow("Original Image");
	cv::imshow("Original Image", image);

	//定义一个带边框的矩形，矩形外部的像素会被标记为背景
	cv::Rect rectangle(50, 25, 210, 180);

	//分割结果
	cv::Mat result;
	//模型
	cv::Mat bgModel, fgModel;

	//Grabcut分割算法
	cv::grabCut(
		image,
		result,
		rectangle,
		bgModel, fgModel,
		5,
		cv::GC_INIT_WITH_RECT);   //使用带边框的矩形模型

	/*
	cv::GC_BGD;           这个值表示明确属于背景的像素（例如本例中矩形之外的像素）
	cv::GC_FGD            这个值表示明确属于前景的像素
	cv::GC_PR_BGD         这个值表示可能属于背景的像素
	cv::GC_PR_FGD         这个值表示可能属于前景的像素（即本例中矩形之内像素的初始值）
	*/

	//取得标记为“可能属于前景的像素”
	/*
	if result(x, y) == cv::GC_PR_FGD
		result(x, y) = 255;
	else
		result(x, y) = 0;
	*/
	
	cv::compare(result, cv::GC_PR_FGD, result, cv::CMP_EQ);

#pragma region Test
	cv::namedWindow("Test");
	cv::imshow("Test", result);


	//创建输出图像
	cv::Mat foreground(image.size(), CV_8UC3, cv::Scalar(255, 255, 255));

	//只有前景部分被复制，不复制背景像素
	image.copyTo(foreground, result);

	//显示画了矩形的输入图像
	cv::rectangle(image, rectangle, cv::Scalar(255, 255, 1));
	cv::namedWindow("Image with rectangle");
	cv::imshow("Image with rectangle", image);

	//显示分割结果
	cv::namedWindow("Foreground");
	cv::imshow("Foreground", foreground);

	cv::waitKey();

}

