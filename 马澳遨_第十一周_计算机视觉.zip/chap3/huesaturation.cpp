﻿
#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <opencv2/imgproc/types_c.h>

void detectHScolor(
	const cv::Mat& image,
	double minHue, double maxHue,
	double minSat, double maxSat,
	cv::Mat& mask)
{
	//将图像从RGB转换到HSV
	cv::Mat hsv;
	cv::cvtColor(image, hsv, CV_BGR2HSV);

	//将HSV的3个通道分割进3幅图像中
	std::vector<cv::Mat>channels;
	cv::split(hsv, channels);
	//channels[0] [1]  [2]分别是色调、饱和度、亮度


	//筛选出色调<maxHue的像素
	cv::Mat mask1;
	cv::threshold(channels[0], mask1, maxHue, 255, cv::THRESH_BINARY_INV);
	//筛选出色调>minHue的像素
	cv::Mat mask2;
	cv::threshold(channels[0], mask2, minHue, 255, cv::THRESH_BINARY);
	//合并色调掩码
	cv::Mat hueMask;
	if (minHue < maxHue)
		hueMask = mask1 & mask2;
	else
		hueMask = mask1 | mask2;

	//筛选出饱和度<maxSat的像素
	cv::threshold(channels[1], mask1, maxSat, 255, cv::THRESH_BINARY_INV);
	//筛选出饱和度>minSat的像素
	cv::threshold(channels[1], mask2, minSat, 255, cv::THRESH_BINARY);
	//合并饱和度掩码
	cv::Mat satMask;
	satMask = mask1 & mask2;

	//组合掩码（二值图像）
	mask = hueMask & satMask;

}


int main()
{
	cv::Mat image = cv::imread("boldt.jpg");
	if (!image.data)
			return 0;
	
		 //显示原始图像
		cv::namedWindow("Original image");
		cv::imshow("Original image", image);
		cv::waitKey();
		
		// convert into HSV space
		cv::Mat hsv;
		cv::cvtColor(image, hsv, CV_BGR2HSV);
	
		//分成三个通道
		std::vector<cv::Mat> channels;
		cv::split(hsv, channels);
		// channels[0] is the 色调
		// channels[1] is the 饱和度
		// channels[2] is the 亮度
	
		// display 亮度
		cv::namedWindow("Value");
		cv::imshow("Value", channels[2]);
		cv::waitKey();
		// display 饱和度
		cv::namedWindow("Saturation");
		cv::imshow("Saturation", channels[1]);
		cv::waitKey();
		// display 色调
		cv::namedWindow("Hue");
		cv::imshow("Hue", channels[0]);
		cv::waitKey();
		//颜色测试
			// image with 混合亮度
			cv::Mat newImage;
		//创建一个原图像亮度通道的副本
		cv::Mat tmp(channels[2].clone());
		// 修改原图像亮度通道内的所有值255
		channels[2] = 255;
		// m重新合并通道
		cv::merge(channels, hsv);
		// 转回BGR
		cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	
		cv::namedWindow("Fixed Value Image");
		cv::imshow("Fixed Value Image", newImage);
		cv::waitKey();
	
		// image with 合并饱和度
		channels[1] = 255;
		channels[2] = tmp;
		cv::merge(channels, hsv);
		cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	
		cv::namedWindow("Fixed saturation");
		cv::imshow("Fixed saturation", newImage);
		cv::waitKey();
	
		// image with 混合亮度和饱和度
		channels[1] = 255;
		channels[2] = 255;
		cv::merge(channels, hsv);
		cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	
		cv::namedWindow("Fixed saturation/value");
		cv::imshow("Fixed saturation/value", newImage);
		cv::waitKey();
	
	//生成调色板
		cv::Mat hs(128, 360, CV_8UC3);
		for (int h = 0; h < 360; h++) {
			for (int s = 0; s < 128; s++) {
				hs.at<cv::Vec3b>(s, h)[0] = h / 2;     // all hue angles
				hs.at<cv::Vec3b>(s, h)[1] = 255 - s * 2; // from high saturation to low
				hs.at<cv::Vec3b>(s, h)[2] = 255;     // constant value
			}
		}
	
		cv::cvtColor(hs, newImage, CV_HSV2BGR);
	
		cv::namedWindow("Hue/Saturation");
		cv::imshow("Hue/Saturation", newImage);
		cv::waitKey();

# pragma region 肤色检测(色调饱和度)
	// 读取图像
	cv::Mat image1 = cv::imread("girl.jpg");
	if (!image1.data)
		return 0;

	// 显示原始图像
	cv::namedWindow("Original image1");
	cv::imshow("Original image1", image1);
	cv::waitKey();

	// 检测肤色
	cv::Mat mask1;
	//调用肤色检测函数
	detectHScolor(image1,
		160, 10, // 色调from 320 度 to 20 度
		25, 166, // 饱和度 from ~0.1 （25/255）to 0.65（166/266）
		mask1);//输出二值掩码图像

	// show masked image
	//创建一个三通道黑色图像
	cv::Mat detected(image1.size(), CV_8UC3, cv::Scalar(0, 0, 0));
	//mask是检测到的肤色的掩码,复制不为零的部分
	image.copyTo(detected, mask1);
	cv::imshow("Detection result", detected);
	cv::waitKey();

#pragma endregion
	return 0;



}
