﻿#include "colordetector.hpp"
#include<vector>
#include <opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>   

cv::Mat ColorDetector::process(const cv::Mat& image)
{
	result.create(image.size(), CV_8U);

	cv::Mat_<cv::Vec3b>::const_iterator it;
	cv::Mat_<cv::Vec3b>::const_iterator itend;

	cv::Mat_<uchar>::iterator itout = result.begin<uchar>();

	if (uselab)
		//将输入图像（默认为RGB色彩空间）转换为另一种色彩空间）
		cv::cvtColor(image, converted, CV_BGR2Lab);

	if (uselab)
	{
		it = converted.begin<cv::Vec3b>();
		itend = converted.end<cv::Vec3b>();
	}
	else
	{
		it = image.begin<cv::Vec3b>();
		itend = image.end<cv::Vec3b>();

	}

	for (; it != itend; ++it, ++itout)
	{
		if (getDistanceToTargetColor(*it) < maxDist)
			*itout = 255;
		else
			*itout = 0;
	}

	return result;

}
